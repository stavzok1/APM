"""
Gene-related processing modules.

- gene_loader: Load and filter genes/lncRNAs from GENCODE
- lncrna_matching: Match lncRNAs to nearby protein-coding genes
- mirna_targets: Process TargetScan miRNA predictions
"""

from .gene_loader import (
    load_genes,
    load_lncrnas,
    filter_genes_by_names,
    filter_lncrnas,
    add_promoter_columns,
    create_genes_bed,
)

from .lncrna_matching import (
    match_lncrnas_to_genes,
    save_lncrna_matching,
)

from .mirna_targets import (
    get_mirna_targets,
)

__all__ = [
    "load_genes",
    "load_lncrnas",
    "filter_genes_by_names",
    "filter_lncrnas",
    "add_promoter_columns",
    "create_genes_bed",
    "match_lncrnas_to_genes",
    "save_lncrna_matching",
    "get_mirna_targets",
]
