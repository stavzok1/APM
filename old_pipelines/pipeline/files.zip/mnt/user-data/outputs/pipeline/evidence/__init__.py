"""
Evidence modules for enhancer-gene links.

Each module handles one evidence type end-to-end:
- screen_links: ENCODE SCREEN experimental + computational
- abc_links: ABC model predictions
- hichip_links: HiChIP loop data
- evidence_merger: Combines all sources into unified gene_links
"""

from .screen_links import (
    build_screen_exp_links,
    build_screen_comp_links,
    collapse_screen_to_nested,
)

from .abc_links import (
    build_abc_links,
    map_abc_to_ccres,
)

from .hichip_links import (
    build_hichip_links,
    integrate_hichip_to_element_table,
)

from .evidence_merger import (
    merge_all_evidence,
    build_unified_gene_links,
)

__all__ = [
    # SCREEN
    "build_screen_exp_links",
    "build_screen_comp_links",
    "collapse_screen_to_nested",
    # ABC
    "build_abc_links",
    "map_abc_to_ccres",
    # HiChIP
    "build_hichip_links",
    "integrate_hichip_to_element_table",
    # Merger
    "merge_all_evidence",
    "build_unified_gene_links",
]
