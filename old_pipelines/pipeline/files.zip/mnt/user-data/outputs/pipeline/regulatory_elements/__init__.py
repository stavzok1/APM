"""
Regulatory element (cCRE) processing modules.

- ccre_loader: Load cCREs and integrate cell-line signals
- distance_matching: Match cCREs to genes by distance tiers
- element_table: Build final element-centric output table
"""

from .ccre_loader import (
    load_ccres,
    add_cell_line_signals,
)

from .distance_matching import (
    match_ccres_to_genes,
    save_distance_matching,
)

from .element_table import (
    build_element_focus_table,
    build_gene_summary_table,
    build_distance_matrix,
)

__all__ = [
    "load_ccres",
    "add_cell_line_signals",
    "match_ccres_to_genes",
    "save_distance_matching",
    "build_element_focus_table",
    "build_gene_summary_table",
    "build_distance_matrix",
]
