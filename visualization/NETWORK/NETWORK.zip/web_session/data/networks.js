var networks = {"blank_network_nodes (1).csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "blank_network_nodes (1).csv",
    "name" : "blank_network_nodes (1).csv",
    "SUID" : 476,
    "__Annotations" : [ "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=968fa092-1605-4b64-907f-1c15310f36a2|fontFamily=Agency FB|name=Sheddase|x=2045.0951294606598|y=-479.71028910422837|z=0|fontSize=69|text=Sheddase", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=c8127393-cbc1-4029-b817-d9837e4728b3|fontFamily=Agency FB|name=ifn-gamma inhibitor|x=713.3754046246794|y=-411.9755049896136|z=4|fontSize=30|text=ifn-gamma inhibitor", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=27f76a9d-c3c2-46a2-8e63-603a01a401b8|fontFamily=Agency FB|name=ifn-gamma inhibitor|x=-485.8031085474019|y=-306.85585584445585|z=5|fontSize=30|text=ifn-gamma inhibitor", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=5c82d142-6ca6-4b1a-b5c1-e8029e7adf9a|fontFamily=Agency FB|name=T-cell immune checkpoints|x=1502.420815369148|y=-933.2561157195775|z=10|fontSize=69|text=T-cell immune checkpoints", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=33539605-0bc7-4a16-9d74-16fbdca8ad6f|fontFamily=Agency FB|name=MHC1 chaperones|x=-104.26620179948651|y=358.1719181091439|z=9|fontSize=69|text=MHC1 chaperones", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=2581f60e-330a-4f76-bead-c8edb29ef742|fontFamily=Agency FB|name=dephosphorylation|x=-1838.7041299012271|y=-195.3629241094284|z=1|fontSize=30|text=dephosphorylation", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=82ef9a2e-7669-44a3-b09e-2905fe32c1c0|fontFamily=Agency FB|name=NK ligands - DNAM1, T-CELL inhib CD96|x=-991.4117724767066|y=2.347131690780957|z=11|fontSize=69|text=NK ligands - DNAM1, T-CELL inhib CD96", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=0dba2365-7497-401e-9559-e27ca21b502d|fontFamily=Agency FB|name=IFN-gamma|x=340.0370524947387|y=-601.1206925896907|z=13|fontSize=69|text=IFN-gamma", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=5769a667-8a0c-4556-a34d-ff4afa83fcb7|fontFamily=Agency FB|name=NKG2D LIGANDS|x=2367.722286375132|y=220.2230893705093|z=8|fontSize=69|text=NKG2D LIGANDS", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=e6880b96-c143-414a-8daf-6c8e835b37e5|fontFamily=Agency FB|name=Immunoproteasome|x=704.1189562000927|y=299.7995232069488|z=7|fontSize=69|text=Immunoproteasome", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=be9850ca-dbeb-4a2c-bcf6-ff82d7d72e83|fontFamily=Agency FB|name=NK ligands|x=2435.122530801978|y=-190.69122209888658|z=16|fontSize=69|text=NK ligands - DNAM1, T-CELL inhib CD96", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=26a52784-1dc7-428c-b17e-484009f4ae0b|fontFamily=Agency FB|name=Kinase|x=-408.08148310422035|y=-449.36763479414816|z=3|fontSize=30|text=Kinase", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=c8907b11-271f-45da-ad8d-a6e8fd658ff4|fontFamily=Agency FB|name=dna binding|x=-1756.472133963192|y=-274.30564020994177|z=2|fontSize=30|text=dna binding", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=8d7e3cd6-c8e6-4f2a-b7a0-99bb8a97001c|fontFamily=Agency FB|name=TNF-alpha|x=312.88377427759644|y=-955.7642221236966|z=12|fontSize=69|text=TNF-alpha", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=56706f81-c890-4d80-941f-992413430bec|fontFamily=Agency FB|name=TGF-beta|x=-1261.7247685858126|y=-768.7124933322748|z=14|fontSize=69|text=TGF-beta", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=99d8d8b1-ae4a-4790-a395-9933a8937643|fontFamily=Agency FB|name=Nf-kB inhibitors|x=-507.08837908395117|y=-1050.780042028774|z=6|fontSize=69|text=Nf-kB inhibitors", "canvas=foreground|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.TextAnnotation|fontStyle=0|uuid=0aff94b4-a648-40f0-bc69-8fa25abb9f47|fontFamily=Agency FB|name=APM|x=660.7482290856989|y=151.8131852246847|z=15|fontSize=69|text=APM" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "2048",
        "shared_name" : "SRC ",
        "name" : "SRC ",
        "SUID" : 2048,
        "selected" : false
      },
      "position" : {
        "x" : -207.41585738316488,
        "y" : -486.72276174455675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2043",
        "shared_name" : "EFGR",
        "name" : "EFGR",
        "SUID" : 2043,
        "selected" : false
      },
      "position" : {
        "x" : -286.27130503425354,
        "y" : -431.71089530217733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2020",
        "shared_name" : "STAT1",
        "name" : "STAT1",
        "SUID" : 2020,
        "selected" : false
      },
      "position" : {
        "x" : -1418.1635534229054,
        "y" : -185.26750325296666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2007",
        "shared_name" : "SHP2 (PTPN11)",
        "name" : "SHP2 (PTPN11)",
        "SUID" : 2007,
        "selected" : false
      },
      "position" : {
        "x" : -1602.6489306780327,
        "y" : -148.05540554720187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2002",
        "shared_name" : "PTPN2",
        "name" : "PTPN2 (TC-PTP)",
        "SUID" : 2002,
        "selected" : false
      },
      "position" : {
        "x" : -1605.0,
        "y" : -199.0
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1997",
        "shared_name" : "PIAS1",
        "name" : "PIAS1",
        "SUID" : 1997,
        "selected" : false
      },
      "position" : {
        "x" : -1599.1073719370033,
        "y" : -251.22315701574914
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1926",
        "shared_name" : "IL-6",
        "name" : "IL-6",
        "SUID" : 1926,
        "selected" : false
      },
      "position" : {
        "x" : -1287.2098060673825,
        "y" : -555.6198325107508
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1921",
        "shared_name" : "stat-3",
        "name" : "stat-3",
        "SUID" : 1921,
        "selected" : false
      },
      "position" : {
        "x" : -1258.8303450358471,
        "y" : -465.62856842533836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1916",
        "shared_name" : "socs3",
        "name" : "socs3",
        "SUID" : 1916,
        "selected" : false
      },
      "position" : {
        "x" : -905.9969429443345,
        "y" : -510.7750578487327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1911",
        "shared_name" : "socs1",
        "name" : "socs1",
        "SUID" : 1911,
        "selected" : false
      },
      "position" : {
        "x" : -1030.0846896141375,
        "y" : -504.1668889619349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1906",
        "shared_name" : "stat-1",
        "name" : "stat-1",
        "SUID" : 1906,
        "selected" : false
      },
      "position" : {
        "x" : -801.278031277338,
        "y" : -623.2431375765403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1901",
        "shared_name" : "tgf-beta",
        "name" : "tgf-beta",
        "SUID" : 1901,
        "selected" : false
      },
      "position" : {
        "x" : -1134.5254100392292,
        "y" : -613.7593281881938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "shared_name" : "AP1",
        "name" : "AP1",
        "SUID" : 1850,
        "selected" : false
      },
      "position" : {
        "x" : -760.7322672993184,
        "y" : -281.8181136553378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "shared_name" : "Node 17",
        "name" : "Node 17",
        "SUID" : 1819,
        "selected" : false
      },
      "position" : {
        "x" : 2341.3491086887157,
        "y" : -160.86944109464042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1802",
        "shared_name" : "AP-1",
        "name" : "AP-1",
        "SUID" : 1802,
        "selected" : false
      },
      "position" : {
        "x" : 2863.5240312406186,
        "y" : -509.39865949239663
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "shared_name" : "tnf-alpha",
        "name" : "tnf-alpha",
        "SUID" : 1791,
        "selected" : false
      },
      "position" : {
        "x" : 293.62274381360913,
        "y" : -1028.9137877828834
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1762",
        "shared_name" : "nf-kB",
        "name" : "nf-kB",
        "SUID" : 1762,
        "selected" : false
      },
      "position" : {
        "x" : 291.23490914986377,
        "y" : -684.9664251329258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1689",
        "shared_name" : "Node 13",
        "name" : "Node 13",
        "SUID" : 1689,
        "selected" : false
      },
      "position" : {
        "x" : 1837.5276737145887,
        "y" : -608.6971733260798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1650",
        "shared_name" : "Node 12",
        "name" : "Node 12",
        "SUID" : 1650,
        "selected" : false
      },
      "position" : {
        "x" : 1820.6271397521987,
        "y" : -494.66231168488804
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "shared_name" : "Node 11",
        "name" : "Node 11",
        "SUID" : 1609,
        "selected" : false
      },
      "position" : {
        "x" : -510.1561153675536,
        "y" : -132.3453724105207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "shared_name" : "Node 10",
        "name" : "Node 10",
        "SUID" : 1406,
        "selected" : false
      },
      "position" : {
        "x" : 2035.8116612783565,
        "y" : -245.19277105398004
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "shared_name" : "ADAM10",
        "name" : "ADAM10",
        "SUID" : 564,
        "selected" : false
      },
      "position" : {
        "x" : 2008.696282723599,
        "y" : -537.7629937077884
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "shared_name" : "ADAM17",
        "name" : "ADAM17",
        "SUID" : 566,
        "selected" : false
      },
      "position" : {
        "x" : 1936.8679867562453,
        "y" : -374.2085336339354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1347",
        "shared_name" : "Node 9",
        "name" : "Node 9",
        "SUID" : 1347,
        "selected" : false
      },
      "position" : {
        "x" : 314.0270317933895,
        "y" : 232.0
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1218",
        "shared_name" : "PSMB1,2,8,9 HUB",
        "name" : "PSMB1,2,8,9 HUB",
        "SUID" : 1218,
        "selected" : false
      },
      "position" : {
        "x" : 1120.4366131304093,
        "y" : 9.553654799269168
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "shared_name" : "ULBP hub",
        "name" : "ULBP hub",
        "NumChildren" : 6,
        "SUID" : 1129,
        "selected" : false
      },
      "position" : {
        "x" : 1755.2263738074084,
        "y" : 257.87755173072827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "shared_name" : "MICA/B hub",
        "name" : "MICA/B hub",
        "NumChildren" : 2,
        "SUID" : 1098,
        "selected" : false
      },
      "position" : {
        "x" : 1918.67817815826,
        "y" : -176.0455056304317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "shared_name" : "Node 5",
        "name" : "Node 5",
        "SUID" : 1069,
        "selected" : false
      },
      "position" : {
        "x" : 781.3172169977994,
        "y" : 7.571364657620759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1010",
        "shared_name" : "Node 4",
        "name" : "Node 4",
        "SUID" : 1010,
        "selected" : false
      },
      "position" : {
        "x" : 304.3820506075044,
        "y" : -9.078869251133343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "shared_name" : "NLRC_5PSMB_hub\n",
        "name" : "NLRC_5PSMB_hub\n",
        "SUID" : 938,
        "selected" : false
      },
      "position" : {
        "x" : 858.964141378036,
        "y" : 156.92658088991698
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "shared_name" : "IFNGR2",
        "name" : "IFNGR2",
        "SUID" : 764,
        "selected" : false
      },
      "position" : {
        "x" : 348.7054241973427,
        "y" : -480.6647869509514
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "shared_name" : "IFNGR1",
        "name" : "IFNGR1",
        "SUID" : 758,
        "selected" : false
      },
      "position" : {
        "x" : 208.26580563909133,
        "y" : -481.4624527869554
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "shared_name" : "IFN-gamma",
        "name" : "IFN-gamma",
        "SUID" : 753,
        "selected" : false
      },
      "position" : {
        "x" : 280.7080019324591,
        "y" : -563.9644901641836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "shared_name" : "PDCD1LG2 (PD-L2)",
        "name" : "PDCD1LG2 (PD-L2)",
        "SUID" : 592,
        "selected" : false
      },
      "position" : {
        "x" : 1720.246720188375,
        "y" : -799.8554461047994
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "shared_name" : "PD-L1(CD274)",
        "name" : "PD-L1(CD274)",
        "SUID" : 590,
        "selected" : false
      },
      "position" : {
        "x" : 1399.6482464945004,
        "y" : -792.1618940865067
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "shared_name" : "NLRC5",
        "name" : "NLRC5",
        "SUID" : 588,
        "selected" : false
      },
      "position" : {
        "x" : 348.8161080514683,
        "y" : -126.96588926771814
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "shared_name" : "IRF2",
        "name" : "IRF2",
        "SUID" : 586,
        "selected" : false
      },
      "position" : {
        "x" : 869.3063280452848,
        "y" : -139.77566026590748
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "IRF1",
        "name" : "IRF1",
        "SUID" : 584,
        "selected" : false
      },
      "position" : {
        "x" : 930.7776346829967,
        "y" : -233.0356726730205
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "shared_name" : "JAK2",
        "name" : "JAK2",
        "SUID" : 582,
        "selected" : false
      },
      "position" : {
        "x" : 349.58041227174147,
        "y" : -424.3871899858137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "shared_name" : "JAK1",
        "name" : "JAK1",
        "SUID" : 580,
        "selected" : false
      },
      "position" : {
        "x" : 206.92906714598985,
        "y" : -422.1906529366186
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "shared_name" : "STAT3",
        "name" : "STAT3",
        "SUID" : 578,
        "selected" : false
      },
      "position" : {
        "x" : 80.2960717317237,
        "y" : -270.36357429676576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "576",
        "shared_name" : "STAT1",
        "name" : "STAT1",
        "SUID" : 576,
        "selected" : false
      },
      "position" : {
        "x" : 363.485816421344,
        "y" : -282.8122596461486
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "shared_name" : "TNFAIP3",
        "name" : "TNFAIP3",
        "SUID" : 574,
        "selected" : false
      },
      "position" : {
        "x" : -330.78288530209164,
        "y" : -892.8266906657591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "shared_name" : "NFKBIA",
        "name" : "NFKBIA",
        "SUID" : 572,
        "selected" : false
      },
      "position" : {
        "x" : -337.958890650728,
        "y" : -810.5221451534695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "shared_name" : "SOCS3",
        "name" : "SOCS3",
        "SUID" : 570,
        "selected" : false
      },
      "position" : {
        "x" : -232.85284587688443,
        "y" : -250.20257947980988
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "shared_name" : "SOCS1",
        "name" : "SOCS1",
        "SUID" : 568,
        "selected" : false
      },
      "position" : {
        "x" : 738.7754491118397,
        "y" : -335.6335402683774
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "shared_name" : "PVRL2",
        "name" : "PVRL2",
        "SUID" : 562,
        "selected" : false
      },
      "position" : {
        "x" : -599.2440183719858,
        "y" : -60.12662297740316
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "shared_name" : "PVR",
        "name" : "PVR",
        "SUID" : 560,
        "selected" : false
      },
      "position" : {
        "x" : -598.9718254458975,
        "y" : -125.84173291816718
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "shared_name" : "ULBP6",
        "name" : "ULBP6",
        "SUID" : 558,
        "selected" : false
      },
      "position" : {
        "x" : 2195.0666459241743,
        "y" : 353.556177703668
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "shared_name" : "ULBP5",
        "name" : "ULBP5",
        "SUID" : 556,
        "selected" : false
      },
      "position" : {
        "x" : 2197.770733304609,
        "y" : 300.53991472999917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "shared_name" : "ULBP4",
        "name" : "ULBP4",
        "SUID" : 554,
        "selected" : false
      },
      "position" : {
        "x" : 2199.8456511459985,
        "y" : 251.38372934613608
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "552",
        "shared_name" : "ULBP3",
        "name" : "ULBP3",
        "SUID" : 552,
        "selected" : false
      },
      "position" : {
        "x" : 2201.550755126074,
        "y" : 199.64604109945137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "shared_name" : "ULBP2",
        "name" : "ULBP2",
        "SUID" : 550,
        "selected" : false
      },
      "position" : {
        "x" : 2204.1461114980334,
        "y" : 151.7397734567368
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "ULBP1",
        "name" : "ULBP1",
        "SUID" : 548,
        "selected" : false
      },
      "position" : {
        "x" : 2201.8010190508635,
        "y" : 105.07465530435437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "shared_name" : "MICB",
        "name" : "MICB",
        "SUID" : 546,
        "selected" : false
      },
      "position" : {
        "x" : 2190.670128080656,
        "y" : -203.03528263272062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "shared_name" : "MICA",
        "name" : "MICA",
        "SUID" : 544,
        "selected" : false
      },
      "position" : {
        "x" : 2194.0238165305213,
        "y" : -115.92329583723495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "shared_name" : "HLA-G",
        "name" : "HLA-G",
        "SUID" : 542,
        "selected" : false
      },
      "position" : {
        "x" : 198.16905219071725,
        "y" : 70.49740185373894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "shared_name" : "HLA-F",
        "name" : "HLA-F",
        "SUID" : 540,
        "selected" : false
      },
      "position" : {
        "x" : 428.13049628037464,
        "y" : 58.077636430007324
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "shared_name" : "HLA-E",
        "name" : "HLA-E",
        "SUID" : 538,
        "selected" : false
      },
      "position" : {
        "x" : 550.586972851958,
        "y" : 60.09611820204807
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "HLA-C",
        "name" : "HLA-C",
        "SUID" : 536,
        "selected" : false
      },
      "position" : {
        "x" : 424.202259582457,
        "y" : 167.83833333888705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "shared_name" : "HLA-B",
        "name" : "HLA-B",
        "SUID" : 534,
        "selected" : false
      },
      "position" : {
        "x" : 319.957280756111,
        "y" : 161.85220831828696
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "shared_name" : "HLA-A",
        "name" : "HLA-A",
        "SUID" : 532,
        "selected" : false
      },
      "position" : {
        "x" : 230.1547301473787,
        "y" : 164.6554537329481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "B2M",
        "name" : "B2M",
        "SUID" : 530,
        "selected" : false
      },
      "position" : {
        "x" : 70.04240793967759,
        "y" : -6.783801886743969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "shared_name" : "PDIA6",
        "name" : "PDIA6",
        "SUID" : 528,
        "selected" : false
      },
      "position" : {
        "x" : 335.0059996180333,
        "y" : 380.7982671311535
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "shared_name" : "PDIA3",
        "name" : "PDIA3",
        "SUID" : 526,
        "selected" : false
      },
      "position" : {
        "x" : 413.97136902439735,
        "y" : 322.1237650365916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "shared_name" : "CALR",
        "name" : "CALR",
        "SUID" : 524,
        "selected" : false
      },
      "position" : {
        "x" : 253.7382728590743,
        "y" : 325.5640462297747
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "shared_name" : "TAPBPR",
        "name" : "TAPBPR",
        "SUID" : 522,
        "selected" : false
      },
      "position" : {
        "x" : 79.20671645969625,
        "y" : 274.4745803131976
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "shared_name" : "TAPBP",
        "name" : "TAPBP",
        "SUID" : 520,
        "selected" : false
      },
      "position" : {
        "x" : 720.3468129509941,
        "y" : -61.98486373681351
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "TAP2",
        "name" : "TAP2",
        "SUID" : 518,
        "selected" : false
      },
      "position" : {
        "x" : 873.1226608698322,
        "y" : 108.45785771224085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "shared_name" : "TAP1",
        "name" : "TAP1",
        "SUID" : 516,
        "selected" : false
      },
      "position" : {
        "x" : 1012.4849008769814,
        "y" : 38.93960819435558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "shared_name" : "PSME4",
        "name" : "PSME4",
        "SUID" : 514,
        "selected" : false
      },
      "position" : {
        "x" : 1235.6410125479426,
        "y" : 304.9188301293506
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "shared_name" : "PSME2",
        "name" : "PSME2",
        "SUID" : 512,
        "selected" : false
      },
      "position" : {
        "x" : 1208.4885130149103,
        "y" : 209.70749139986805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "shared_name" : "PSME1",
        "name" : "PSME1",
        "SUID" : 510,
        "selected" : false
      },
      "position" : {
        "x" : 1309.3760043592613,
        "y" : 176.70440658560523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "shared_name" : "PSMB10",
        "name" : "PSMB10",
        "SUID" : 508,
        "selected" : false
      },
      "position" : {
        "x" : 847.0662572052868,
        "y" : 233.89279930143238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "PSMB8",
        "name" : "PSMB8",
        "SUID" : 506,
        "selected" : false
      },
      "position" : {
        "x" : 964.4629737673522,
        "y" : 232.18651851307393
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "shared_name" : "PSMB9",
        "name" : "PSMB9",
        "SUID" : 504,
        "selected" : false
      },
      "position" : {
        "x" : 1085.780655199198,
        "y" : 206.59666543283794
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "2053",
        "source" : "2043",
        "target" : "578",
        "shared_name" : "EFGR (interacts with) STAT3",
        "name" : "EFGR (interacts with) STAT3",
        "interaction" : "interacts with",
        "SUID" : 2053,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2031",
        "source" : "2007",
        "target" : "2020",
        "shared_name" : "SHP2 (PTPN11) (interacts with) STAT1",
        "name" : "SHP2 (PTPN11) (interacts with) STAT1",
        "interaction" : "interacts with",
        "SUID" : 2031,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2037",
        "source" : "2002",
        "target" : "2020",
        "shared_name" : "PTPN2 (TC-PTP) (interacts with) STAT1",
        "name" : "PTPN2 (TC-PTP) (interacts with) STAT1",
        "interaction" : "interacts with",
        "SUID" : 2037,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2025",
        "source" : "1997",
        "target" : "2020",
        "shared_name" : "PIAS1 (interacts with) STAT1",
        "name" : "PIAS1 (interacts with) STAT1",
        "interaction" : "interacts with",
        "SUID" : 2025,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1959",
        "source" : "1926",
        "target" : "1921",
        "shared_name" : "IL-6 (interacts with) stat-3",
        "name" : "IL-6 (interacts with) stat-3",
        "interaction" : "interacts with",
        "SUID" : 1959,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1957",
        "source" : "1926",
        "target" : "1901",
        "shared_name" : "IL-6 (interacts with) tgf-beta",
        "name" : "IL-6 (interacts with) tgf-beta",
        "interaction" : "interacts with",
        "SUID" : 1957,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1933",
        "source" : "1916",
        "target" : "1901",
        "shared_name" : "socs3 (interacts with) tgf-beta",
        "name" : "socs3 (interacts with) tgf-beta",
        "interaction" : "interacts with",
        "SUID" : 1933,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1935",
        "source" : "1911",
        "target" : "1901",
        "shared_name" : "socs1 (interacts with) tgf-beta",
        "name" : "socs1 (interacts with) tgf-beta",
        "interaction" : "interacts with",
        "SUID" : 1935,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1951",
        "source" : "1901",
        "target" : "1906",
        "shared_name" : "tgf-beta (interacts with) stat-1",
        "name" : "tgf-beta (interacts with) stat-1",
        "interaction" : "interacts with",
        "SUID" : 1951,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1832",
        "source" : "1819",
        "target" : "546",
        "shared_name" : "Node 17 (interacts with) MICB",
        "name" : "Node 17 (interacts with) MICB",
        "interaction" : "interacts with",
        "SUID" : 1832,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1830",
        "source" : "1819",
        "target" : "544",
        "shared_name" : "Node 17 (interacts with) MICA",
        "name" : "Node 17 (interacts with) MICA",
        "interaction" : "interacts with",
        "SUID" : 1830,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1824",
        "source" : "1802",
        "target" : "1819",
        "shared_name" : "AP-1 (interacts with) Node 17",
        "name" : "AP-1 (interacts with) Node 17",
        "interaction" : "interacts with",
        "SUID" : 1824,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1813",
        "source" : "1802",
        "target" : "1650",
        "shared_name" : "AP-1 (interacts with) Node 12",
        "name" : "AP-1 (interacts with) Node 12",
        "interaction" : "interacts with",
        "SUID" : 1813,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1807",
        "source" : "1802",
        "target" : "1791",
        "shared_name" : "Node 16 (interacts with) tnf-alpha",
        "name" : "Node 16 (interacts with) tnf-alpha",
        "interaction" : "interacts with",
        "SUID" : 1807,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1981",
        "source" : "1791",
        "target" : "572",
        "shared_name" : "tnf-alpha (interacts with) NFKBIA",
        "name" : "tnf-alpha (interacts with) NFKBIA",
        "interaction" : "interacts with",
        "SUID" : 1981,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1855",
        "source" : "1791",
        "target" : "1850",
        "shared_name" : "tnf-alpha (interacts with) AP1",
        "name" : "tnf-alpha (interacts with) AP1",
        "interaction" : "interacts with",
        "SUID" : 1855,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1885",
        "source" : "1762",
        "target" : "572",
        "shared_name" : "nf-kB (interacts with) NFKBIA",
        "name" : "nf-kB (interacts with) NFKBIA",
        "interaction" : "interacts with",
        "SUID" : 1885,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1796",
        "source" : "1762",
        "target" : "1791",
        "shared_name" : "nf-kB (interacts with) tnf-alpha",
        "name" : "nf-kB (interacts with) tnf-alpha",
        "interaction" : "interacts with",
        "SUID" : 1796,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "source" : "1762",
        "target" : "1098",
        "shared_name" : "nf-kB (interacts with) MICA/B hub",
        "name" : "nf-kB (interacts with) MICA/B hub",
        "interaction" : "interacts with",
        "SUID" : 1779,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "source" : "1689",
        "target" : "564",
        "shared_name" : "Node 13 (interacts with) ADAM10",
        "name" : "Node 13 (interacts with) ADAM10",
        "interaction" : "interacts with",
        "SUID" : 1702,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "source" : "1689",
        "target" : "566",
        "shared_name" : "Node 13 (interacts with) ADAM17",
        "name" : "Node 13 (interacts with) ADAM17",
        "interaction" : "interacts with",
        "SUID" : 1700,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1694",
        "source" : "1689",
        "target" : "590",
        "shared_name" : "Node 13 (interacts with) PD-L1(CD274)",
        "name" : "Node 13 (interacts with) PD-L1(CD274)",
        "interaction" : "interacts with",
        "SUID" : 1694,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "source" : "1650",
        "target" : "1762",
        "shared_name" : "Node 12 (interacts with) nf-kB",
        "name" : "Node 12 (interacts with) nf-kB",
        "interaction" : "interacts with",
        "SUID" : 1773,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1671",
        "source" : "1650",
        "target" : "564",
        "shared_name" : "Node 12 (interacts with) ADAM10",
        "name" : "Node 12 (interacts with) ADAM10",
        "interaction" : "interacts with",
        "SUID" : 1671,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "source" : "1609",
        "target" : "1762",
        "shared_name" : "Node 11 (interacts with) nf-kB",
        "name" : "Node 11 (interacts with) nf-kB",
        "interaction" : "interacts with",
        "SUID" : 1785,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1616",
        "source" : "1609",
        "target" : "560",
        "shared_name" : "Node 11 (interacts with) PVR",
        "name" : "Node 11 (interacts with) PVR",
        "interaction" : "interacts with",
        "SUID" : 1616,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1614",
        "source" : "1609",
        "target" : "562",
        "shared_name" : "Node 11 (interacts with) PVRL2",
        "name" : "Node 11 (interacts with) PVRL2",
        "interaction" : "interacts with",
        "SUID" : 1614,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "source" : "564",
        "target" : "1406",
        "shared_name" : "ADAM10 (interacts with) Node 10",
        "name" : "ADAM10 (interacts with) Node 10",
        "interaction" : "interacts with",
        "SUID" : 1435,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1667",
        "source" : "566",
        "target" : "1650",
        "shared_name" : "ADAM17 (interacts with) Node 12",
        "name" : "ADAM17 (interacts with) Node 12",
        "interaction" : "interacts with",
        "SUID" : 1667,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "source" : "566",
        "target" : "1406",
        "shared_name" : "ADAM17 (interacts with) Node 10",
        "name" : "ADAM17 (interacts with) Node 10",
        "interaction" : "interacts with",
        "SUID" : 1433,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1720",
        "source" : "1347",
        "target" : "522",
        "shared_name" : "Node 9 (interacts with) TAPBPR",
        "name" : "Node 9 (interacts with) TAPBPR",
        "interaction" : "interacts with",
        "SUID" : 1720,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1370",
        "source" : "1347",
        "target" : "536",
        "shared_name" : "Node 9 (interacts with) HLA-C",
        "name" : "Node 9 (interacts with) HLA-C",
        "interaction" : "interacts with",
        "SUID" : 1370,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1364",
        "source" : "1347",
        "target" : "534",
        "shared_name" : "Node 9 (interacts with) HLA-B",
        "name" : "Node 9 (interacts with) HLA-B",
        "interaction" : "interacts with",
        "SUID" : 1364,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1352",
        "source" : "1347",
        "target" : "524",
        "shared_name" : "Node 9 (interacts with) CALR",
        "name" : "Node 9 (interacts with) CALR",
        "interaction" : "interacts with",
        "SUID" : 1352,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1242",
        "source" : "1218",
        "target" : "512",
        "shared_name" : "PSMB1,2,8,9 HUB (interacts with) PSME2",
        "name" : "PSMB1,2,8,9 HUB (interacts with) PSME2",
        "interaction" : "interacts with",
        "SUID" : 1242,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1170",
        "source" : "1129",
        "target" : "584",
        "shared_name" : "ULBP hub (interacts with) IRF1",
        "name" : "ULBP hub (interacts with) IRF1",
        "interaction" : "interacts with",
        "SUID" : 1170,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "1129",
        "target" : "558",
        "shared_name" : "ULBP hub (interacts with) ULBP6",
        "name" : "ULBP hub (interacts with) ULBP6",
        "interaction" : "interacts with",
        "SUID" : 1164,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1152",
        "source" : "1129",
        "target" : "550",
        "shared_name" : "ULBP hub (interacts with) ULBP2",
        "name" : "ULBP hub (interacts with) ULBP2",
        "interaction" : "interacts with",
        "SUID" : 1152,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1146",
        "source" : "1129",
        "target" : "548",
        "shared_name" : "ULBP hub (interacts with) ULBP1",
        "name" : "ULBP hub (interacts with) ULBP1",
        "interaction" : "interacts with",
        "SUID" : 1146,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "source" : "1129",
        "target" : "554",
        "shared_name" : "ULBP hub (interacts with) ULBP4",
        "name" : "ULBP hub (interacts with) ULBP4",
        "interaction" : "interacts with",
        "SUID" : 1140,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "source" : "1129",
        "target" : "556",
        "shared_name" : "ULBP hub (interacts with) ULBP5",
        "name" : "ULBP hub (interacts with) ULBP5",
        "interaction" : "interacts with",
        "SUID" : 1134,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "1069",
        "target" : "516",
        "shared_name" : "Node 5 (interacts with) TAP1",
        "name" : "Node 5 (interacts with) TAP1",
        "interaction" : "interacts with",
        "SUID" : 1086,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "938",
        "target" : "508",
        "shared_name" : "NLRC_5PSMB_hub\n (interacts with) PSMB10",
        "name" : "NLRC_5PSMB_hub\n (interacts with) PSMB10",
        "interaction" : "interacts with",
        "SUID" : 961,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "764",
        "target" : "582",
        "shared_name" : "activates",
        "name" : "activates",
        "SUID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "780",
        "source" : "758",
        "target" : "580",
        "shared_name" : "activates",
        "name" : "activates",
        "SUID" : 780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "753",
        "target" : "764",
        "shared_name" : "activate",
        "name" : "activate",
        "SUID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "source" : "753",
        "target" : "758",
        "shared_name" : "activates",
        "name" : "activates",
        "SUID" : 770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1767",
        "source" : "590",
        "target" : "1762",
        "shared_name" : "PD-L1(CD274) (interacts with) nf-kB",
        "name" : "PD-L1(CD274) (interacts with) nf-kB",
        "interaction" : "interacts with",
        "SUID" : 1767,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1732",
        "source" : "588",
        "target" : "538",
        "shared_name" : "NLRC5 (interacts with) HLA-E",
        "name" : "NLRC5 (interacts with) HLA-E",
        "interaction" : "interacts with",
        "SUID" : 1732,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "588",
        "target" : "520",
        "shared_name" : "NLRC5 (interacts with) TAPBP",
        "name" : "NLRC5 (interacts with) TAPBP",
        "interaction" : "interacts with",
        "SUID" : 1092,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "588",
        "target" : "1069",
        "shared_name" : "NLRC5 (interacts with) Node 5",
        "name" : "NLRC5 (interacts with) Node 5",
        "interaction" : "interacts with",
        "SUID" : 1074,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "588",
        "target" : "1010",
        "shared_name" : "NLRC5 (interacts with) Node 4",
        "name" : "NLRC5 (interacts with) Node 4",
        "interaction" : "interacts with",
        "SUID" : 1015,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "588",
        "target" : "938",
        "shared_name" : "NLRC5 (interacts with) NLRC_5PSMB_hub\n",
        "name" : "NLRC5 (interacts with) NLRC_5PSMB_hub\n",
        "interaction" : "interacts with",
        "SUID" : 945,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "source" : "586",
        "target" : "584",
        "shared_name" : "IRF2 (interacts with) IRF1",
        "name" : "IRF2 (interacts with) IRF1",
        "interaction" : "interacts with",
        "SUID" : 1317,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "source" : "584",
        "target" : "1010",
        "shared_name" : "IRF1 (interacts with) Node 4",
        "name" : "IRF1 (interacts with) Node 4",
        "interaction" : "interacts with",
        "SUID" : 1335,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "584",
        "target" : "1098",
        "shared_name" : "IRF1 (interacts with) Node 6",
        "name" : "IRF1 (interacts with) Node 6",
        "interaction" : "interacts with",
        "SUID" : 1103,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "580",
        "target" : "570",
        "shared_name" : "JAK1 (interacts with) SOCS3",
        "name" : "JAK1 (interacts with) SOCS3",
        "interaction" : "interacts with",
        "SUID" : 1182,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "580",
        "target" : "578",
        "shared_name" : "JAK1 (interacts with) STAT3",
        "name" : "JAK1 (interacts with) STAT3",
        "interaction" : "interacts with",
        "SUID" : 831,
        "shared_interaction" : "weakly phosphorylate",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "source" : "580",
        "target" : "576",
        "shared_name" : "JAK1 (phosphorylate) STAT1",
        "name" : "JAK1 (interacts with) STAT1",
        "interaction" : "phosphorylation",
        "SUID" : 806,
        "shared_interaction" : "phosphorylate",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2057",
        "source" : "578",
        "target" : "2048",
        "shared_name" : "STAT3 (interacts with) SRC ",
        "name" : "STAT3 (interacts with) SRC ",
        "interaction" : "interacts with",
        "SUID" : 2057,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1756",
        "source" : "578",
        "target" : "542",
        "shared_name" : "STAT3 (interacts with) HLA-G",
        "name" : "STAT3 (interacts with) HLA-G",
        "interaction" : "interacts with",
        "SUID" : 1756,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "578",
        "target" : "1650",
        "shared_name" : "STAT3 (interacts with) Node 12",
        "name" : "STAT3 (interacts with) Node 12",
        "interaction" : "interacts with",
        "SUID" : 1661,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1634",
        "source" : "578",
        "target" : "1609",
        "shared_name" : "STAT3 (interacts with) Node 11",
        "name" : "STAT3 (interacts with) Node 11",
        "interaction" : "interacts with",
        "SUID" : 1634,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "source" : "578",
        "target" : "590",
        "shared_name" : "STAT3 (interacts with) PD-L1(CD274)",
        "name" : "STAT3 (interacts with) PD-L1(CD274)",
        "interaction" : "interacts with",
        "SUID" : 1200,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "source" : "578",
        "target" : "582",
        "shared_name" : "STAT3 (interacts with) JAK2",
        "name" : "STAT3 (interacts with) JAK2",
        "interaction" : "interacts with",
        "SUID" : 836,
        "shared_interaction" : "weakly phosphorylate",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "source" : "576",
        "target" : "590",
        "shared_name" : "STAT1 (interacts with) PD-L1(CD274)",
        "name" : "STAT1 (interacts with) PD-L1(CD274)",
        "interaction" : "interacts with",
        "SUID" : 1291,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "576",
        "target" : "1218",
        "shared_name" : "STAT1 (interacts with) PSMB1,2,8,9 HUB",
        "name" : "STAT1 (interacts with) PSMB1,2,8,9 HUB",
        "interaction" : "interacts with",
        "SUID" : 1223,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1212",
        "source" : "576",
        "target" : "516",
        "shared_name" : "STAT1 (interacts with) TAP1",
        "name" : "STAT1 (interacts with) TAP1",
        "interaction" : "interacts with",
        "SUID" : 1212,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1194",
        "source" : "576",
        "target" : "578",
        "shared_name" : "STAT1 (interacts with) STAT3",
        "name" : "STAT1 (interacts with) STAT3",
        "interaction" : "interacts with",
        "SUID" : 1194,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "source" : "576",
        "target" : "588",
        "shared_name" : "STAT1 (interacts with) NLRC5",
        "name" : "STAT1 (interacts with) NLRC5",
        "interaction" : "interacts with",
        "SUID" : 826,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "576",
        "target" : "586",
        "shared_name" : "STAT1 (interacts with) IRF2",
        "name" : "STAT1 (interacts with) IRF2",
        "interaction" : "interacts with",
        "SUID" : 821,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "816",
        "source" : "576",
        "target" : "584",
        "shared_name" : "STAT1 (interacts with) IRF1",
        "name" : "STAT1 (interacts with) IRF1",
        "interaction" : "interacts with",
        "SUID" : 816,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "source" : "576",
        "target" : "582",
        "shared_name" : "STAT1 (phosphorylate) JAK2",
        "name" : "STAT1 (interacts with) JAK2",
        "interaction" : "phosphorylation",
        "SUID" : 811,
        "shared_interaction" : "phosphorylate",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1977",
        "source" : "574",
        "target" : "1791",
        "shared_name" : "TNFAIP3 (interacts with) tnf-alpha",
        "name" : "TNFAIP3 (interacts with) tnf-alpha",
        "interaction" : "interacts with",
        "SUID" : 1977,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "source" : "574",
        "target" : "1762",
        "shared_name" : "TNFAIP3 (interacts with) nf-kB",
        "name" : "TNFAIP3 (interacts with) nf-kB",
        "interaction" : "interacts with",
        "SUID" : 1881,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1188",
        "source" : "570",
        "target" : "582",
        "shared_name" : "SOCS3 (interacts with) JAK2",
        "name" : "SOCS3 (interacts with) JAK2",
        "interaction" : "interacts with",
        "SUID" : 1188,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "570",
        "target" : "578",
        "shared_name" : "SOCS3 (interacts with) STAT3",
        "name" : "SOCS3 (interacts with) STAT3",
        "interaction" : "interacts with",
        "SUID" : 1176,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1299",
        "source" : "568",
        "target" : "582",
        "shared_name" : "SOCS1 (interacts with) JAK2",
        "name" : "SOCS1 (interacts with) JAK2",
        "interaction" : "interacts with",
        "SUID" : 1299,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1297",
        "source" : "568",
        "target" : "580",
        "shared_name" : "SOCS1 (interacts with) JAK1",
        "name" : "SOCS1 (interacts with) JAK1",
        "interaction" : "interacts with",
        "SUID" : 1297,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1206",
        "source" : "568",
        "target" : "576",
        "shared_name" : "SOCS1 (interacts with) STAT1",
        "name" : "SOCS1 (interacts with) STAT1",
        "interaction" : "interacts with",
        "SUID" : 1206,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1867",
        "source" : "562",
        "target" : "1850",
        "shared_name" : "PVRL2 (interacts with) AP1",
        "name" : "PVRL2 (interacts with) AP1",
        "interaction" : "interacts with",
        "SUID" : 1867,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1861",
        "source" : "560",
        "target" : "1850",
        "shared_name" : "PVR (interacts with) AP1",
        "name" : "PVR (interacts with) AP1",
        "interaction" : "interacts with",
        "SUID" : 1861,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "552",
        "target" : "1129",
        "shared_name" : "ULBP3 (interacts with) ULBP hub",
        "name" : "ULBP3 (interacts with) ULBP hub",
        "interaction" : "interacts with",
        "SUID" : 1158,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "546",
        "target" : "1406",
        "shared_name" : "MICB (interacts with) Node 10",
        "name" : "MICB (interacts with) Node 10",
        "interaction" : "interacts with",
        "SUID" : 1415,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "546",
        "target" : "1098",
        "shared_name" : "MICB (interacts with) Node 6",
        "name" : "MICB (interacts with) Node 6",
        "interaction" : "interacts with",
        "SUID" : 1113,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "source" : "544",
        "target" : "1406",
        "shared_name" : "MICA (interacts with) Node 10",
        "name" : "MICA (interacts with) Node 10",
        "interaction" : "interacts with",
        "SUID" : 1413,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "544",
        "target" : "1098",
        "shared_name" : "MICA (interacts with) Node 6",
        "name" : "MICA (interacts with) Node 6",
        "interaction" : "interacts with",
        "SUID" : 1111,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1750",
        "source" : "540",
        "target" : "588",
        "shared_name" : "HLA-F (interacts with) NLRC5",
        "name" : "HLA-F (interacts with) NLRC5",
        "interaction" : "interacts with",
        "SUID" : 1750,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1744",
        "source" : "540",
        "target" : "584",
        "shared_name" : "HLA-F (interacts with) IRF1",
        "name" : "HLA-F (interacts with) IRF1",
        "interaction" : "interacts with",
        "SUID" : 1744,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1738",
        "source" : "538",
        "target" : "584",
        "shared_name" : "HLA-E (interacts with) IRF1",
        "name" : "HLA-E (interacts with) IRF1",
        "interaction" : "interacts with",
        "SUID" : 1738,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "536",
        "target" : "1010",
        "shared_name" : "HLA-C (interacts with) Node 4",
        "name" : "HLA-C (interacts with) Node 4",
        "interaction" : "interacts with",
        "SUID" : 1029,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "534",
        "target" : "1010",
        "shared_name" : "HLA-B (interacts with) Node 4",
        "name" : "HLA-B (interacts with) Node 4",
        "interaction" : "interacts with",
        "SUID" : 1031,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1358",
        "source" : "532",
        "target" : "1347",
        "shared_name" : "HLA-A (interacts with) Node 9",
        "name" : "HLA-A (interacts with) Node 9",
        "interaction" : "interacts with",
        "SUID" : 1358,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "532",
        "target" : "1010",
        "shared_name" : "HLA-A (interacts with) Node 4",
        "name" : "HLA-A (interacts with) Node 4",
        "interaction" : "interacts with",
        "SUID" : 1025,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1726",
        "source" : "530",
        "target" : "522",
        "shared_name" : "B2M (interacts with) TAPBPR",
        "name" : "B2M (interacts with) TAPBPR",
        "interaction" : "interacts with",
        "SUID" : 1726,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1640",
        "source" : "530",
        "target" : "1609",
        "shared_name" : "B2M (interacts with) Node 11",
        "name" : "B2M (interacts with) Node 11",
        "interaction" : "interacts with",
        "SUID" : 1640,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "source" : "530",
        "target" : "588",
        "shared_name" : "B2M (interacts with) NLRC5",
        "name" : "B2M (interacts with) NLRC5",
        "interaction" : "interacts with",
        "SUID" : 1329,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "530",
        "target" : "584",
        "shared_name" : "B2M (interacts with) IRF1",
        "name" : "B2M (interacts with) IRF1",
        "interaction" : "interacts with",
        "SUID" : 1323,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "530",
        "target" : "576",
        "shared_name" : "B2M (interacts with) STAT1",
        "name" : "B2M (interacts with) STAT1",
        "interaction" : "interacts with",
        "SUID" : 1267,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1376",
        "source" : "526",
        "target" : "520",
        "shared_name" : "PDIA3 (interacts with) TAPBP",
        "name" : "PDIA3 (interacts with) TAPBP",
        "interaction" : "interacts with",
        "SUID" : 1376,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "source" : "524",
        "target" : "526",
        "shared_name" : "CALR (interacts with) PDIA3",
        "name" : "CALR (interacts with) PDIA3",
        "interaction" : "interacts with",
        "SUID" : 1341,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "518",
        "target" : "1069",
        "shared_name" : "TAP2 (interacts with) Node 5",
        "name" : "TAP2 (interacts with) Node 5",
        "interaction" : "interacts with",
        "SUID" : 1080,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "510",
        "target" : "1218",
        "shared_name" : "PSME1 (interacts with) PSMB1,2,8,9 HUB",
        "name" : "PSME1 (interacts with) PSMB1,2,8,9 HUB",
        "interaction" : "interacts with",
        "SUID" : 1229,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1261",
        "source" : "506",
        "target" : "1218",
        "shared_name" : "PSMB8 (interacts with) PSMB1,2,8,9 HUB",
        "name" : "PSMB8 (interacts with) PSMB1,2,8,9 HUB",
        "interaction" : "interacts with",
        "SUID" : 1261,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "506",
        "target" : "938",
        "shared_name" : "PSMB8 (interacts with) NLRC_5PSMB_hub\n",
        "name" : "PSMB8 (interacts with) NLRC_5PSMB_hub\n",
        "interaction" : "interacts with",
        "SUID" : 957,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1255",
        "source" : "504",
        "target" : "1218",
        "shared_name" : "PSMB9 (interacts with) PSMB1,2,8,9 HUB",
        "name" : "PSMB9 (interacts with) PSMB1,2,8,9 HUB",
        "interaction" : "interacts with",
        "SUID" : 1255,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "504",
        "target" : "938",
        "shared_name" : "PSMB9 (interacts with) NLRC_5PSMB_hub\n",
        "name" : "PSMB9 (interacts with) NLRC_5PSMB_hub\n",
        "interaction" : "interacts with",
        "SUID" : 953,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}