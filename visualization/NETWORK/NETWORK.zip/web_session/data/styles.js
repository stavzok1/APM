var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Solid",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "font-size" : 14,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 0.0,
      "width" : 40.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(102,102,102)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 40.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(204,204,204)",
      "font-size" : 10,
      "width" : 12.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(102,102,102)",
      "font-size" : 20,
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "shape" : "ellipse",
      "border-width" : 15.0,
      "width" : 50.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(58,127,182)",
      "text-valign" : "center",
      "text-halign" : "right",
      "height" : 50.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)",
      "font-size" : 10,
      "width" : 20.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample3",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(206,206,206)",
      "font-size" : 14,
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "shape" : "ellipse",
      "border-width" : 8.0,
      "width" : 20.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(61,154,255)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "height" : 20.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)",
      "font-size" : 10,
      "width" : 2.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default black",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(204,204,204)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,153,0)",
      "shape" : "ellipse",
      "border-width" : 0.0,
      "width" : 15.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "height" : 15.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(0,153,0)",
      "font-size" : 10,
      "width" : 2.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Marquee",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(102,102,102)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "shape" : "ellipse",
      "border-width" : 10.0,
      "width" : 20.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(0,204,255)",
      "text-valign" : "bottom",
      "text-halign" : "center",
      "height" : 20.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(255,255,255)",
      "source-arrow-color" : "rgb(255,255,255)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(102,102,102)",
      "line-color" : "rgb(255,255,255)",
      "font-size" : 8,
      "width" : 2.0,
      "target-arrow-shape" : "triangle",
      "source-arrow-shape" : "none",
      "line-style" : "dashed",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "size_rank",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "font-size" : 9,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "rectangle",
      "border-width" : 0.0,
      "width" : 12.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(204,204,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 12.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(76,76,76)",
      "font-size" : 10,
      "width" : 2.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Directed",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,153,255)",
      "font-size" : 8,
      "border-opacity" : 1.0,
      "border-color" : "rgb(145,145,145)",
      "shape" : "ellipse",
      "border-width" : 5.0,
      "width" : 45.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 45.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(204,204,204)",
      "source-arrow-color" : "rgb(204,204,204)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(51,153,255)",
      "line-color" : "rgb(204,204,204)",
      "font-size" : 12,
      "width" : 5.0,
      "target-arrow-shape" : "triangle",
      "source-arrow-shape" : "none",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "font-size" : 10,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 0.0,
      "width" : 25.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(127,205,187)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 25.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(51,51,51)",
      "line-color" : "rgb(153,153,153)",
      "font-size" : 10,
      "width" : 1.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'pp']",
    "css" : {
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'pd']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Universe",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(255,255,255)",
      "font-size" : 18,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 0.0,
      "width" : 40.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(0,0,0)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 40.0,
      "font-family" : "Monospaced.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(153,153,153)",
      "font-size" : 10,
      "width" : 2.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-color" : "rgb(204,204,204)",
      "shape" : "roundrectangle",
      "border-width" : 0.0,
      "width" : 75.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(137,208,245)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 35.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(253,141,60)",
      "line-color" : "rgb(115,115,115)",
      "font-size" : 10,
      "width" : 2.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Minimal",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "font-size" : 9,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "rectangle",
      "border-width" : 0.0,
      "width" : 42.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 42.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(76,76,76)",
      "font-size" : 10,
      "width" : 2.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "BioPAX_SIF",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 2.0,
      "width" : 60.0,
      "background-opacity" : 0.49019607843137253,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,153,153)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 40.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "shape" : "hexagon"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "background-color" : "rgb(153,204,255)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "width" : 4.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'interacts-with']",
    "css" : {
      "line-color" : "rgb(0,85,0)",
      "target-arrow-color" : "rgb(0,85,0)",
      "source-arrow-color" : "rgb(0,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'chemical-affects']",
    "css" : {
      "line-color" : "rgb(240,144,0)",
      "target-arrow-color" : "rgb(240,144,0)",
      "source-arrow-color" : "rgb(240,144,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-state-change-of']",
    "css" : {
      "line-color" : "rgb(0,0,192)",
      "target-arrow-color" : "rgb(0,0,192)",
      "source-arrow-color" : "rgb(0,0,192)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of']",
    "css" : {
      "line-color" : "rgb(112,0,0)",
      "target-arrow-color" : "rgb(112,0,0)",
      "source-arrow-color" : "rgb(112,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consumption-controled-by']",
    "css" : {
      "line-color" : "rgb(255,51,0)",
      "target-arrow-color" : "rgb(255,51,0)",
      "source-arrow-color" : "rgb(255,51,0)"
    }
  }, {
    "selector" : "edge[interaction = 'reacts-with']",
    "css" : {
      "line-color" : "rgb(0,255,0)",
      "target-arrow-color" : "rgb(0,255,0)",
      "source-arrow-color" : "rgb(0,255,0)"
    }
  }, {
    "selector" : "edge[interaction = 'neighbor-of']",
    "css" : {
      "line-color" : "rgb(0,170,0)",
      "target-arrow-color" : "rgb(0,170,0)",
      "source-arrow-color" : "rgb(0,170,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-expression-of']",
    "css" : {
      "line-color" : "rgb(0,160,160)",
      "target-arrow-color" : "rgb(0,160,160)",
      "source-arrow-color" : "rgb(0,160,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-phosphorylation-of']",
    "css" : {
      "line-color" : "rgb(0,0,255)",
      "target-arrow-color" : "rgb(0,0,255)",
      "source-arrow-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of-chemical']",
    "css" : {
      "line-color" : "rgb(160,0,0)",
      "target-arrow-color" : "rgb(160,0,0)",
      "source-arrow-color" : "rgb(160,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'used-to-produce']",
    "css" : {
      "line-color" : "rgb(247,85,0)",
      "target-arrow-color" : "rgb(247,85,0)",
      "source-arrow-color" : "rgb(247,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'in-complex-with']",
    "css" : {
      "line-color" : "rgb(240,0,160)",
      "target-arrow-color" : "rgb(240,0,160)",
      "source-arrow-color" : "rgb(240,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-production-of']",
    "css" : {
      "line-color" : "rgb(0,204,240)",
      "target-arrow-color" : "rgb(0,204,240)",
      "source-arrow-color" : "rgb(0,204,240)"
    }
  }, {
    "selector" : "edge[interaction = 'catalysis-precedes']",
    "css" : {
      "line-color" : "rgb(112,0,160)",
      "target-arrow-color" : "rgb(112,0,160)",
      "source-arrow-color" : "rgb(112,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'interacts-with']",
    "css" : {
      "line-color" : "rgb(0,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'chemical-affects']",
    "css" : {
      "line-color" : "rgb(240,144,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-state-change-of']",
    "css" : {
      "line-color" : "rgb(0,0,192)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of']",
    "css" : {
      "line-color" : "rgb(112,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consumption-controled-by']",
    "css" : {
      "line-color" : "rgb(255,51,0)"
    }
  }, {
    "selector" : "edge[interaction = 'reacts-with']",
    "css" : {
      "line-color" : "rgb(0,255,0)"
    }
  }, {
    "selector" : "edge[interaction = 'neighbor-of']",
    "css" : {
      "line-color" : "rgb(0,170,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-expression-of']",
    "css" : {
      "line-color" : "rgb(0,160,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-phosphorylation-of']",
    "css" : {
      "line-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of-chemical']",
    "css" : {
      "line-color" : "rgb(160,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'used-to-produce']",
    "css" : {
      "line-color" : "rgb(247,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'in-complex-with']",
    "css" : {
      "line-color" : "rgb(240,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-production-of']",
    "css" : {
      "line-color" : "rgb(0,204,240)"
    }
  }, {
    "selector" : "edge[interaction = 'catalysis-precedes']",
    "css" : {
      "line-color" : "rgb(112,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-expression-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'chemical-affects']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-state-change-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-phosphorylation-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of-chemical']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'used-to-produce']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'consumption-controled-by']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-production-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'catalysis-precedes']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(19,58,96)",
      "font-size" : 8,
      "border-opacity" : 1.0,
      "border-color" : "rgb(51,153,255)",
      "shape" : "ellipse",
      "border-width" : 20.0,
      "width" : 50.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 50.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,204)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(51,153,255)",
      "font-size" : 10,
      "width" : 3.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Curved",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(102,102,102)",
      "font-size" : 14,
      "border-opacity" : 1.0,
      "border-color" : "rgb(255,255,255)",
      "shape" : "ellipse",
      "border-width" : 7.0,
      "width" : 18.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(254,196,79)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "height" : 18.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(255,255,255)",
      "content" : "",
      "source-arrow-color" : "rgb(255,255,255)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(255,255,255)",
      "font-size" : 10,
      "width" : 3.0,
      "target-arrow-shape" : "triangle",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Nested Network Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 2.0,
      "width" : 60.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 40.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(shared_name)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "text-valign" : "bottom"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "border-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(64,64,64)",
      "font-size" : 10,
      "width" : 1.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "BioPAX",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(0,0,0)",
      "font-size" : 12,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,102,102)",
      "shape" : "ellipse",
      "border-width" : 2.0,
      "width" : 20.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 20.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'GeneticInteraction']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'BiochemicalReaction']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Interaction']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TransportWithBiochemicalReaction']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'ComplexAssembly']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Conversion']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Degradation']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TemplateReactionRegulation']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Control']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TemplateReaction']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'MolecularInteraction']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Modulation']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Catalysis']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Transport']",
    "css" : {
      "height" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'SimplePhysicalEntity']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Rna']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'GeneticInteraction']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'BiochemicalReaction']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Interaction']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TransportWithBiochemicalReaction']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'ComplexAssembly']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Conversion']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Protein']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'RnaRegion']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "shape" : "diamond"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Degradation']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TemplateReactionRegulation']",
    "css" : {
      "shape" : "triangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Control']",
    "css" : {
      "shape" : "triangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'PhysicalEntity']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'DnaRegion']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'SmallMolecule']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Dna']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TemplateReaction']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'MolecularInteraction']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Modulation']",
    "css" : {
      "shape" : "triangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Catalysis']",
    "css" : {
      "shape" : "triangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Transport']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Protein-phosphorylated']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'GeneticInteraction']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'BiochemicalReaction']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Interaction']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TransportWithBiochemicalReaction']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'ComplexAssembly']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Conversion']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Degradation']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TemplateReactionRegulation']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Control']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'TemplateReaction']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'MolecularInteraction']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Modulation']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Catalysis']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Transport']",
    "css" : {
      "width" : 13.4
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "border-color" : "rgb(0,102,102)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(64,64,64)",
      "content" : "",
      "source-arrow-color" : "rgb(64,64,64)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(64,64,64)",
      "font-size" : 10,
      "width" : 1.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_NONCOMPETITIVE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_OTHER']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_UNCOMPETITIVE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'cofactor']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION_ALLOSTERIC']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'right']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_ALLOSTERIC']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'controlled']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'contains']",
    "css" : {
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_UNKMECH']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_IRREVERSIBLE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_COMPETITIVE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION_UNKMECH']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION_NONALLOSTERIC']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Gradient1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(204,204,204)",
      "font-size" : 8,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 0.0,
      "width" : 30.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(0,0,0)",
      "text-valign" : "bottom",
      "text-halign" : "right",
      "height" : 30.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(102,102,102)",
      "font-size" : 10,
      "width" : 1.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Big Labels",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "color" : "rgb(51,51,51)",
      "font-size" : 24,
      "border-opacity" : 1.0,
      "border-color" : "rgb(0,0,0)",
      "shape" : "ellipse",
      "border-width" : 0.0,
      "width" : 5.0,
      "background-opacity" : 1.0,
      "text-opacity" : 1.0,
      "background-color" : "rgb(255,255,255)",
      "text-valign" : "center",
      "text-halign" : "center",
      "height" : 5.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '512' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '544' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '1921' ]",
    "css" : {
      "background-color" : "rgb(115,115,115)"
    }
  }, {
    "selector" : "node[ id = '1218' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '514' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '546' ]",
    "css" : {
      "background-color" : "rgb(177,0,38)"
    }
  }, {
    "selector" : "node[ id = '578' ]",
    "css" : {
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1762' ]",
    "css" : {
      "background-color" : "rgb(237,248,177)"
    }
  }, {
    "selector" : "node[ id = '1347' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '516' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '548' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '580' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '518' ]",
    "css" : {
      "background-color" : "rgb(190,186,218)"
    }
  }, {
    "selector" : "node[ id = '550' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-color" : "rgb(247,252,185)"
    }
  }, {
    "selector" : "node[ id = '1926' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '520' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '552' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "node[ id = '1129' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1609' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1098' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "background-color" : "rgb(116,196,118)",
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '522' ]",
    "css" : {
      "background-color" : "rgb(253,218,236)"
    }
  }, {
    "selector" : "node[ id = '554' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-color" : "rgb(250,159,181)"
    }
  }, {
    "selector" : "node[ id = '1802' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '938' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '524' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '556' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-color" : "rgb(29,145,192)"
    }
  }, {
    "selector" : "node[ id = '1069' ]",
    "css" : {
      "background-opacity" : 0.0,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '1901' ]",
    "css" : {
      "shape" : "ellipse",
      "background-color" : "rgb(82,82,82)"
    }
  }, {
    "selector" : "node[ id = '1997' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '526' ]",
    "css" : {
      "background-color" : "rgb(239,237,245)"
    }
  }, {
    "selector" : "node[ id = '558' ]",
    "css" : {
      "background-color" : "rgb(239,59,44)"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-color" : "rgb(253,224,221)"
    }
  }, {
    "selector" : "node[ id = '528' ]",
    "css" : {
      "background-color" : "rgb(231,225,239)"
    }
  }, {
    "selector" : "node[ id = '560' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '753' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[ id = '530' ]",
    "css" : {
      "background-color" : "rgb(140,107,177)"
    }
  }, {
    "selector" : "node[ id = '562' ]",
    "css" : {
      "background-color" : "rgb(251,106,74)"
    }
  }, {
    "selector" : "node[ id = '1650' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '2002' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '1010' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '532' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '564' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '534' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '566' ]",
    "css" : {
      "background-color" : "rgb(166,118,29)"
    }
  }, {
    "selector" : "node[ id = '758' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1911' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '2007' ]",
    "css" : {
      "background-color" : "rgb(253,208,162)"
    }
  }, {
    "selector" : "node[ id = '504' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '536' ]",
    "css" : {
      "background-color" : "rgb(136,65,157)"
    }
  }, {
    "selector" : "node[ id = '568' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1689' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '506' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '538' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '570' ]",
    "css" : {
      "background-color" : "rgb(253,174,107)"
    }
  }, {
    "selector" : "node[ id = '1850' ]",
    "css" : {
      "background-color" : "rgb(153,45,128)"
    }
  }, {
    "selector" : "node[ id = '1819' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '508' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '540' ]",
    "css" : {
      "background-color" : "rgb(255,217,47)"
    }
  }, {
    "selector" : "node[ id = '572' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '764' ]",
    "css" : {
      "background-color" : "rgb(236,226,240)"
    }
  }, {
    "selector" : "node[ id = '1916' ]",
    "css" : {
      "background-color" : "rgb(254,153,41)"
    }
  }, {
    "selector" : "node[ id = '1406' ]",
    "css" : {
      "background-opacity" : 0.00392156862745098,
      "font-size" : 1,
      "width" : 1.0
    }
  }, {
    "selector" : "node[ id = '510' ]",
    "css" : {
      "background-color" : "rgb(252,197,192)"
    }
  }, {
    "selector" : "node[ id = '542' ]",
    "css" : {
      "background-color" : "rgb(254,217,118)"
    }
  }, {
    "selector" : "node[ id = '574' ]",
    "css" : {
      "background-color" : "rgb(127,205,187)"
    }
  }, {
    "selector" : "node[ id = '1791' ]",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "target-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(183,183,183)",
      "font-size" : 10,
      "width" : 1.0,
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[ id = '1152' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1376' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1824' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1025' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '961' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1634' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '770' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1667' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1092' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1188' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1700' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1732' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1796' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '836' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1029' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2053' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1317' ]",
    "css" : {
      "source-arrow-color" : "rgb(254,178,76)",
      "target-arrow-color" : "rgb(254,178,76)",
      "line-color" : "rgb(252,146,114)",
      "target-arrow-shape" : "tee",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1413' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1861' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1158' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1702' ]",
    "css" : {
      "target-arrow-color" : "rgb(255,255,51)",
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '806' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1830' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1031' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1223' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1255' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1415' ]",
    "css" : {
      "source-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1671' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1767' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '775' ]",
    "css" : {
      "line-color" : "rgb(78,179,211)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1959' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1352' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)"
    }
  }, {
    "selector" : "edge[ id = '1640' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1832' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2057' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '2025' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1194' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1738' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1291' ]",
    "css" : {
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1323' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '811' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1867' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1164' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '780' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1229' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1261' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1773' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1933' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1134' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1358' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1614' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1103' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1807' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1935' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '2031' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1200' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1616' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1744' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '816' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1297' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1329' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '945' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1074' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1170' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1267' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1299' ]",
    "css" : {
      "target-arrow-color" : "rgb(251,106,74)",
      "line-color" : "rgb(251,106,74)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1779' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1140' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1364' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1813' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '821' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '2037' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1206' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1750' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[ id = '1111' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1335' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1015' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1080' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1176' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1113' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1433' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '1785' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1881' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '953' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1977' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1146' ]",
    "css" : {
      "color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1242' ]",
    "css" : {
      "source-arrow-color" : "rgb(161,217,155)",
      "target-arrow-color" : "rgb(161,217,155)",
      "line-color" : "rgb(161,217,155)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1370' ]",
    "css" : {
      "source-arrow-color" : "rgb(229,245,224)",
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '826' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1435' ]",
    "css" : {
      "line-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge[ id = '795' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1212' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1756' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1661' ]",
    "css" : {
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)"
    }
  }, {
    "selector" : "edge[ id = '1885' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '957' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "source-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1981' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1086' ]",
    "css" : {
      "source-arrow-color" : "rgb(116,196,118)",
      "target-arrow-color" : "rgb(116,196,118)",
      "line-color" : "rgb(116,196,118)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '1182' ]",
    "css" : {
      "source-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "source-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[ id = '1694' ]",
    "css" : {
      "target-arrow-color" : "rgb(65,182,196)",
      "line-color" : "rgb(255,255,51)",
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[ id = '831' ]",
    "css" : {
      "target-arrow-color" : "rgb(229,245,224)",
      "line-color" : "rgb(229,245,224)",
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[ id = '1855' ]",
    "css" : {
      "line-color" : "rgb(116,196,118)",
      "line-style" : "dotted"
    }
  }, {
    "selector" : "edge[ id = '1951' ]",
    "css" : {
      "target-arrow-color" : "rgb(239,59,44)",
      "line-color" : "rgb(239,59,44)",
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]